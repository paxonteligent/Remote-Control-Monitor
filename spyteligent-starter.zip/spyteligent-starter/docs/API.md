# API contract

The starter exposes `POST /api/telemetry` for authenticated dashboard/session testing. Native apps should not write arbitrary rows directly with a user session unless the intended ownership model is enforced.

## POST /api/telemetry

Headers:
- `Authorization: Bearer <Supabase access token>`
- `Content-Type: application/json`

Body:
```json
{
  "device_id": "UUID",
  "battery_percent": 87,
  "storage_total_bytes": 128000000000,
  "storage_free_bytes": 64000000000
}
```

The route validates the Supabase user and verifies the device belongs to that user before inserting telemetry. It is a starter endpoint, not a substitute for device-scoped credentials in production.

## Recommended production endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/pairing/challenges` | Create a short-lived pairing challenge |
| POST | `/api/pairing/confirm` | Confirm owner and device pairing |
| DELETE | `/api/devices/:id` | Revoke/unpair a device |
| POST | `/api/devices/:id/telemetry` | Device-scoped battery/storage report |
| POST | `/api/devices/:id/location` | Opt-in location report |
| POST | `/api/devices/:id/media/upload-url` | Request short-lived upload authorization |
| GET | `/api/devices/:id/media` | List media metadata user is authorized to view |
| POST | `/api/devices/:id/screen-sessions` | Record a user-initiated session |
| DELETE | `/api/devices/:id/screen-sessions/:sessionId` | Mark session stopped |

These endpoints are design targets, not all implemented in this starter. Add rate limits, validation, idempotency, audit events and device credential revocation before production.
