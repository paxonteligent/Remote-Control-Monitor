# Security baseline

1. **RLS on every user-owned table.** Policies bind `owner_id` to `auth.uid()`.
2. **Private media bucket.** No public bucket. Generate short-lived signed URLs only after checking the media row belongs to the current user.
3. **No service-role key in clients.** The service-role key bypasses RLS and belongs only in a trusted server environment.
4. **Pairing.** One-time, expiring challenges; confirm both ends; credentials must be revocable and scoped to one device.
5. **Consent records.** Store feature-level grants, when granted/revoked, and the disclosure version shown.
6. **Audit.** Log location reads, media views/downloads, pairing, revocation, and screen-sharing session starts/stops.
7. **Minimize data.** Keep only necessary telemetry; define retention windows; support export and deletion.
8. **Location.** Off by default. Provide clear purpose, visible active state, and a stop button. Avoid collecting location when it is not needed.
9. **Media.** User-selected only. Do not scrape app-private directories or attempt to bypass OS privacy controls.
10. **Restricted data.** Do not collect SMS/call logs or broad app inventories unless platform rules explicitly allow it for the app's declared core purpose.
11. **Transport and secrets.** HTTPS/TLS; rotate secrets; never put secrets in logs or source control.
12. **Threat model.** Assume a device may be lost, a session token stolen, or a user account compromised. Add MFA, rate limits, alerts and revocation.
