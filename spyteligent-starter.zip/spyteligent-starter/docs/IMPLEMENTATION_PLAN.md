# Implementation plan

## Phase 0 — Foundations
- Create Supabase project and apply the initial migration.
- Configure Auth, private Storage bucket, email confirmation, and production redirect URLs.
- Run the web app locally and validate RLS with two test users.
- Use HTTPS everywhere; add privacy policy and data deletion UX before public launch.

## Phase 1 — Web dashboard
- Sign-in/sign-up and session management.
- Device list, device detail, last-seen time, battery/storage cards.
- Location map only for locations the user has permission to view.
- Media gallery using signed URLs generated for authorized users.
- Realtime updates for telemetry.
- Device revoke, export, and delete actions.

## Phase 2 — Android companion
- Device pairing and revoke handling.
- Battery and storage telemetry.
- Explicit foreground location-sharing toggle with a persistent notification if background updates are added.
- Media selection via Android Photo Picker and upload to private Storage.
- Installed-app information only where package visibility and Google Play policies allow it.
- Screen sharing only through MediaProjection system consent.
- Do not implement general SMS/call-log collection unless the app is eligible under platform policy and the user explicitly chooses a qualifying role.

## Phase 3 — iOS companion
- Device pairing and revoke handling.
- Battery reporting while app is active; avoid promising continuous monitoring where iOS limits execution.
- Core Location with clear purpose strings and user-controlled authorization.
- PhotosUI picker for user-selected media.
- Screen sharing through the system-supported broadcast/capture flow available for the target iOS version.
- Show call/message history and app inventory as unavailable on standard iOS devices.

## Phase 4 — Production hardening
- Device-scoped short-lived credentials and refresh/revocation.
- Rate limits and schema validation for ingestion.
- Audit log for viewing location, opening media, and starting/stopping screen sessions.
- Retention controls, account deletion, media deletion, backups and incident response.
- Store policy review, privacy labels/disclosures, accessibility, localization and penetration testing.
