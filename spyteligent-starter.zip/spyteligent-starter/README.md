# Spyteligent Starter

A privacy-first starter monorepo for an authorized, user-consented device-management app.

## Stack

- Web dashboard: Next.js App Router + TypeScript, deployed on Vercel
- Backend: Supabase Auth, PostgreSQL, Row Level Security, private Storage, Realtime
- Android companion: Kotlin / Android Studio
- iOS companion: Swift / Xcode

This is a starter project, not a finished device-management product. The web dashboard and Supabase schema are the main working foundation. Native projects contain focused starter code and implementation notes; they still need platform-specific testing, signing, permission UX, and production hardening.

## Privacy and platform boundaries

- Pair only devices the signed-in user owns or is explicitly authorized to manage.
- Device telemetry is sent only after the companion app is configured and the user has granted relevant permissions.
- Location must be opt-in, clearly disclosed, and stoppable from the companion app.
- Media is uploaded only after the user selects files using the system picker.
- Screen sharing must be initiated on the device and use the platform's visible system consent flow.
- Android package inventory is restricted by package visibility and Google Play policy. Do not request `QUERY_ALL_PACKAGES` unless the app qualifies and has approval.
- SMS and call-log access are restricted on Android, commonly to qualifying default handlers or approved policy exceptions. The starter does not collect SMS or call logs.
- iOS does not provide general APIs for reading other apps' SMS/iMessage history, call history, or a full installed-app inventory. The starter does not attempt to bypass those restrictions.

## Repository layout

```text
spyteligent-starter/
├── apps/
│   ├── web/                    # Next.js dashboard
│   ├── android/                # Kotlin Android starter
│   └── ios/                    # Swift iOS starter
├── supabase/
│   ├── migrations/             # Schema + RLS policies
│   └── seed.sql
├── docs/
│   ├── API.md
│   ├── SECURITY.md
│   └── IMPLEMENTATION_PLAN.md
├── .env.example
└── README.md
```

## 1. Create the Supabase project

1. Create a project at https://supabase.com.
2. In the SQL Editor, run `supabase/migrations/202610240001_initial_schema.sql`.
3. In Storage, create a **private** bucket named `device-media`.
4. Enable email/password or your preferred sign-in provider under Authentication.
5. Copy the Project URL and anon/publishable key into `apps/web/.env.local`.

Never put a Supabase `service_role` key in browser code or commit it to Git.

## 2. Run the web dashboard

Requirements: Node.js 20+ and npm.

```bash
cd apps/web
cp ../../.env.example .env.local
# Fill in NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm install
npm run dev
```

Open http://localhost:3000. Sign up/sign in with Supabase Auth. The dashboard lists devices owned by the authenticated user. Until a companion app is paired and sending data, the UI will show an empty state.

## 3. Deploy to Vercel

1. Push this repository to a Git provider.
2. Import the repository into Vercel.
3. Set the project root directory to `apps/web`.
4. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
5. Deploy.

Do not store privileged service-role secrets in `NEXT_PUBLIC_*` variables.

## 4. Android starter

Open `apps/android` in Android Studio. This folder contains a minimal Android project source skeleton. Create/confirm a project using a current stable Android Studio and SDK, then copy the Kotlin source and manifest entries into it if Gradle versions differ.

The sample reports battery percentage and available storage after the user taps **Send status**. Location permission is requested only after the user taps **Enable location sharing**. The sample deliberately does not implement silent background tracking, SMS/call-log collection, broad app enumeration, or unattended screen capture.

Set the Supabase project URL and anon key in `DeviceReporter.kt` for local testing only, or preferably inject them using a build configuration. For production, use short-lived, revocable device credentials and a dedicated pairing flow rather than embedding a long-lived secret in the app.

## 5. iOS starter

Open `apps/ios/Spyteligent` in Xcode on a Mac. Add the provided Swift source to a new iOS App project. Set a unique bundle identifier and configure the location usage description in Info.plist. The sample uses Core Location after explicit user action and reports battery level when available.

The included PhotosUI example lets the user select media. It does not upload media automatically. Add a private-storage upload flow only after implementing authenticated pairing and short-lived upload authorization.

## 6. Pairing and production architecture

The database supports an owner-linked device record. For a production pairing flow:

1. The signed-in dashboard creates a one-time pairing challenge with a short expiry.
2. The companion app displays a confirmation code or QR.
3. The signed-in owner confirms the same challenge in both places.
4. Backend creates a device record with a revocable credential scoped to that device.
5. The native app uses that credential only for allowed device-scoped writes.
6. The owner can revoke the device, which invalidates the credential.

Do not use a shared hard-coded API secret. Do not expose a service-role key to native apps. For a production-grade device credential exchange, add a server-side pairing endpoint and store only hashed credential material.

## 7. Testing checklist

- [ ] RLS prevents user A from reading user B's devices, locations, telemetry, and media metadata.
- [ ] Revoking a device prevents further telemetry writes.
- [ ] Location remains off until explicit opt-in and can be stopped.
- [ ] Media picker selection is required before upload.
- [ ] Private Storage objects cannot be fetched by an unrelated user.
- [ ] Screen sharing uses system consent and has a visible stop action.
- [ ] Unsupported capabilities are shown as unavailable rather than fabricated.
- [ ] Audit logs and retention/deletion flows are tested.
- [ ] Android policy eligibility is reviewed before requesting restricted permissions.
- [ ] iOS privacy descriptions and App Store disclosures match actual behavior.

See `docs/IMPLEMENTATION_PLAN.md`, `docs/API.md`, and `docs/SECURITY.md`.
