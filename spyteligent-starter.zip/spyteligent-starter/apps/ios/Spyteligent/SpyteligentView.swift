import SwiftUI
import CoreLocation
import PhotosUI
import UIKit

@MainActor
final class LocationReporter: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var message = "Location sharing is off."
    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
    }

    func requestOneReading() {
        guard CLLocationManager.locationServicesEnabled() else {
            message = "Location Services are disabled in Settings."
            return
        }
        manager.requestWhenInUseAuthorization()
        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
            manager.requestLocation()
            message = "Requested one location reading. No upload occurs in this starter."
        } else {
            message = "Allow location in the system prompt to continue."
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
            message = "Location permission granted. Tap the location button to request a reading."
        } else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            message = "Location permission denied. Sharing remains off."
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        message = String(format: "One reading: %.5f, %.5f (±%.0f m). Not uploaded.", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy)
        // TODO: upload only after explicit pairing and consent using a revocable device credential.
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        message = "Location unavailable: \(error.localizedDescription)"
    }
}

struct SpyteligentView: View {
    @StateObject private var location = LocationReporter()
    @State private var battery = "Tap to read battery"
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var selectedMediaCount = 0

    var body: some View {
        NavigationStack {
            List {
                Section("Device status") {
                    Text(battery)
                    Button("Read battery status") { readBattery() }
                    Text("Battery reporting is available while this app is running; iOS may limit background execution.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Location") {
                    Text(location.message)
                    Button("Request one location reading") { location.requestOneReading() }
                }
                Section("Photos and videos") {
                    PhotosPicker(selection: $selectedItems, maxSelectionCount: 10, matching: .any(of: [.images, .videos])) {
                        Label("Choose photos or videos", systemImage: "photo.on.rectangle.angled")
                    }
                    Text("\(selectedItems.count) item(s) selected. Selection does not upload anything.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Button("Clear selection") { selectedItems = [] }
                }
                Section("Platform limitations") {
                    Label("No general access to SMS/iMessage or call history", systemImage: "hand.raised")
                    Label("No general installed-app inventory", systemImage: "app.badge")
                    Label("Screen sharing requires a system-approved, user-started broadcast flow", systemImage: "rectangle.on.rectangle")
                }
            }
            .navigationTitle("Spyteligent")
        }
        .onChange(of: selectedItems) { _, items in selectedMediaCount = items.count }
    }

    private func readBattery() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        let level = UIDevice.current.batteryLevel
        battery = level < 0 ? "Battery level unavailable" : "Battery: \(Int(level * 100))% (local reading; not uploaded)"
        // TODO: report through a secure, paired-device endpoint when the app is active.
    }
}
