# iOS companion starter

Create a new iOS App project in Xcode on macOS, then add `SpyteligentView.swift` to the target. Set `NSLocationWhenInUseUsageDescription` in Info.plist to a clear user-facing explanation.

This sample reports battery level while the app is open and requests a single location reading only after the user taps a button. It uses PhotosUI for user-selected media. It does not access SMS/iMessage history, call history, or a general installed-app list.
