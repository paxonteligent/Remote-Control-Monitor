# Web app

Next.js App Router dashboard inspired by the supplied Spyteligent HTML reference. It supports Supabase sign-in, owner-scoped device records, latest telemetry display, and record revocation. It does not remotely control a device without the native companion app and a secure pairing flow.

See the root README for setup.
