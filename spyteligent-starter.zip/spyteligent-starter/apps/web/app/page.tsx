"use client";

import { useEffect, useMemo, useState } from "react";
import { Activity, BatteryCharging, Bell, Camera, CheckCircle2, ChevronRight, CircleHelp, Clock3, Database, HardDrive, LayoutDashboard, MapPin, MonitorSmartphone, Plus, Radio, Settings, ShieldCheck, Smartphone, Video, Wifi, X } from "lucide-react";
import { getSupabase } from "../lib/supabase";

type Device = {
  id: string; device_name: string; platform: string; model: string | null;
  os_version: string | null; last_seen_at: string | null; is_revoked: boolean;
};
type Telemetry = { battery_percent: number | null; storage_total_bytes: number | null; storage_free_bytes: number | null; reported_at: string };

const fmtBytes = (n?: number | null) => {
  if (n == null) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"]; let v = n, i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(i > 1 ? 1 : 0)} ${units[i]}`;
};
const relative = (d?: string | null) => d ? new Date(d).toLocaleString() : "No reports yet";

export default function Dashboard() {
  const supabase = useMemo(() => getSupabase(), []);
  const [session, setSession] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"signin"|"signup">("signin");
  const [devices, setDevices] = useState<Device[]>([]);
  const [telemetry, setTelemetry] = useState<Record<string, Telemetry>>({});
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [newName, setNewName] = useState("");
  const [newPlatform, setNewPlatform] = useState("android");
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, [supabase]);

  async function refresh() {
    if (!supabase || !session?.user) return;
    const { data, error } = await supabase.from("devices").select("*").eq("owner_id", session.user.id).eq("is_revoked", false).order("created_at", { ascending: false });
    if (error) { setMessage(error.message); return; }
    const rows = (data ?? []) as Device[];
    setDevices(rows);
    const results = await Promise.all(rows.map(async d => {
      const { data: latest } = await supabase.from("device_telemetry").select("battery_percent,storage_total_bytes,storage_free_bytes,reported_at").eq("device_id", d.id).order("reported_at", { ascending: false }).limit(1).maybeSingle();
      return [d.id, latest as Telemetry | null] as const;
    }));
    setTelemetry(Object.fromEntries(results.filter((x): x is readonly [string, Telemetry] => !!x[1])));
  }

  useEffect(() => { if (session?.user) refresh(); }, [session?.user?.id]);

  async function authSubmit(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setMessage("");
    const result = authMode === "signin"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password });
    if (result.error) setMessage(result.error.message);
    else if (authMode === "signup" && !result.data.session) setMessage("Check your email to confirm your account, then sign in.");
  }

  async function signOut() { await supabase?.auth.signOut(); setDevices([]); setTelemetry({}); }

  async function addDevice(e: React.FormEvent) {
    e.preventDefault(); if (!supabase || !session?.user || !newName.trim()) return;
    const { error } = await supabase.from("devices").insert({ owner_id: session.user.id, device_name: newName.trim(), platform: newPlatform });
    if (error) setMessage(error.message);
    else { setMessage("Device record created. Pairing with a real companion app is a separate step; this record alone does not connect a phone."); setNewName(""); setShowAdd(false); await refresh(); }
  }

  if (!supabase) return <div className="card auth"><h1>Configure Supabase</h1><p className="muted">Set <code>NEXT_PUBLIC_SUPABASE_URL</code> and <code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code> in <code>apps/web/.env.local</code>, then restart the dev server.</p></div>;
  if (loading) return <div className="auth muted">Loading Spyteligent…</div>;
  if (!session) return <form className="card auth" onSubmit={authSubmit}>
    <div className="brand"><span className="brand-mark"><MonitorSmartphone size={20}/></span> spyteligent</div>
    <p className="eyebrow" style={{marginTop:28}}>Secure device management</p><h1>{authMode === "signin" ? "Welcome back" : "Create your account"}</h1>
    <p className="muted small">Manage only devices you own or are authorized to manage.</p>
    <label className="small">Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email"/>
    <label className="small">Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={8} autoComplete={authMode==="signin"?"current-password":"new-password"}/>
    {message && <p className="small muted">{message}</p>}
    <button className="button primary" style={{width:"100%"}}>{authMode==="signin"?"Sign in":"Sign up"}</button>
    <button type="button" className="button" style={{width:"100%",marginTop:10}} onClick={()=>{setAuthMode(authMode==="signin"?"signup":"signin");setMessage("");}}>{authMode==="signin"?"Create an account":"I already have an account"}</button>
  </form>;

  const latest = devices.map(d => telemetry[d.id]).filter(Boolean) as Telemetry[];
  const avgBattery = latest.length ? Math.round(latest.reduce((sum,t)=>sum+(t.battery_percent ?? 0),0)/latest.length) : null;
  const totalFree = latest.reduce((sum,t)=>sum+(t.storage_free_bytes ?? 0),0);

  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark"><MonitorSmartphone size={20}/></span> spyteligent</div>
      <div><div className="nav-label">WORKSPACE</div><a className="nav-link active"><LayoutDashboard size={17}/> Overview</a><a className="nav-link" href="#devices"><Smartphone size={17}/> My devices</a><a className="nav-link" href="#location"><MapPin size={17}/> Location</a><a className="nav-link" href="#media"><Camera size={17}/> Media</a></div>
      <div><div className="nav-label">MANAGEMENT</div><a className="nav-link" href="#features"><Activity size={17}/> Device features</a><a className="nav-link" href="#security"><ShieldCheck size={17}/> Security & consent</a><a className="nav-link" href="#settings"><Settings size={17}/> Settings</a></div>
      <div style={{marginTop:"auto",padding:12,border:"1px solid var(--line)",borderRadius:13,background:"#0c1b31"}}><ShieldCheck size={20} color="#45d6a0"/><p style={{fontSize:12,fontWeight:700,margin:"10px 0 5px"}}>Privacy first</p><p className="muted" style={{fontSize:11,lineHeight:1.6,margin:0}}>Only permissioned data from paired devices is displayed.</p></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="eyebrow">DEVICE CONTROL CENTER</div><h1 className="page-title">Overview</h1></div><div className="top-actions"><span className="pill"><Wifi size={13} style={{display:"inline",marginRight:5}}/> Secure workspace</span><button className="button" onClick={()=>refresh()} aria-label="Refresh"><Activity size={15}/></button><button className="button" onClick={()=>setShowAdd(true)}><Plus size={15} style={{display:"inline",marginRight:5}}/>Add device</button><div className="avatar">{session.user.email?.[0]?.toUpperCase() ?? "U"}</div></div></header>
      {message && <div className="notice" role="status">{message} <button onClick={()=>setMessage("")} style={{float:"right",background:"none",border:0,color:"inherit"}}><X size={14}/></button></div>}
      <section className="grid stats">
        <Stat icon={<Smartphone size={18}/>} label="Paired devices" value={String(devices.length)} sub="Active device records"/>
        <Stat icon={<BatteryCharging size={18}/>} label="Average battery" value={avgBattery===null?"—":`${avgBattery}%`} sub={latest.length?"From latest reports":"Waiting for telemetry"}/>
        <Stat icon={<HardDrive size={18}/>} label="Free storage" value={latest.length?fmtBytes(totalFree):"—"} sub="Across reporting devices"/>
        <Stat icon={<ShieldCheck size={18}/>} label="Security status" value="Protected" sub="RLS and account sign-in enabled"/>
      </section>
      <div className="section-head" id="devices"><h2>My devices</h2><span className="muted small">{devices.length} device{devices.length===1?"":"s"}</span></div>
      <section className="grid device-layout">
        <div className="card">
          {devices.length===0 ? <div className="empty"><Smartphone size={28} style={{margin:"0 auto 10px",display:"block"}}/><strong style={{display:"block",color:"#dce8fa",marginBottom:7}}>No devices added yet</strong>Add a device record to begin setup. A record is not a live connection; the companion app pairing flow must be implemented and completed separately.<div style={{marginTop:14}}><button className="button primary" onClick={()=>setShowAdd(true)}><Plus size={14} style={{display:"inline",marginRight:5}}/>Add first device</button></div></div> :
            devices.map(d => { const t=telemetry[d.id]; return <div className="device-row" key={d.id}><div className="device-icon"><Smartphone size={22}/></div><div className="device-meta"><strong>{d.device_name}</strong><span>{d.platform.toUpperCase()} {d.model ? `· ${d.model}` : ""} · {d.os_version ?? "OS version not reported"}</span><div style={{marginTop:7}} className="status"><span className="dot"/>{t ? `Last report ${relative(t.reported_at)}` : "Waiting for first report"}</div></div><div style={{textAlign:"right"}}><strong style={{fontSize:14}}>{t?.battery_percent==null?"—":`${t.battery_percent}%`}</strong><div className="muted" style={{fontSize:10,marginTop:4}}>battery</div><button className="button" style={{marginTop:8,padding:"6px 8px"}} onClick={async()=>{if(!supabase) return; const ok=window.confirm(`Revoke ${d.device_name}? This marks the record revoked; production device credentials must also be revoked server-side.`);if(!ok)return;const {error}=await supabase.from("devices").update({is_revoked:true}).eq("id",d.id);if(error)setMessage(error.message);else{setMessage("Device record revoked.");await refresh();}}}>Revoke</button></div></div>; })
          }
        </div>
        <div className="card" id="location"><div className="section-head" style={{margin:"0 0 15px"}}><h2>Location sharing</h2><MapPin size={17} color="#68a9ff"/></div><div className="map-placeholder"><div className="map-center"/></div><div className="map-caption"><span className="muted">No location available until opted in</span><span style={{color:"#e9c76d"}}><CircleHelp size={13} style={{display:"inline",marginRight:4}}/>Permission required</span></div><div className="notice">Location is not inferred from IP address. The companion app must request OS permission and the user must enable sharing before coordinates appear here.</div></div>
      </section>
      <div className="section-head" id="features"><h2>Device features</h2><span className="muted small">Platform support varies</span></div>
      <section className="card"><div className="feature-list">
        <Feature icon={<BatteryCharging size={17}/>} title="Battery & storage" status="Supported with reports"/>
        <Feature icon={<MapPin size={17}/>} title="GPS location" status="Opt-in permission"/>
        <Feature icon={<Camera size={17}/>} title="Photos & videos" status="User-selected media"/>
        <Feature icon={<Database size={17}/>} title="Installed apps" status="Restricted / platform-limited"/>
        <Feature icon={<Radio size={17}/>} title="Calls & messages" status="Restricted; not collected"/>
        <Feature icon={<Video size={17}/>} title="Screen sharing" status="User-started system consent"/>
      </div></section>
      <div className="section-head" id="media"><h2>Media library</h2><span className="muted small">Private storage</span></div>
      <section className="card"><div className="empty"><Camera size={26} style={{display:"block",margin:"0 auto 10px"}}/><strong style={{display:"block",color:"#dce8fa",marginBottom:7}}>No media uploaded</strong>Media will appear here only after a paired device user selects photos or videos and approves upload.</div></section>
      <div className="section-head" id="security"><h2>Security & consent</h2></div>
      <section className="card"><div style={{display:"flex",alignItems:"center",gap:12}}><CheckCircle2 color="#35d69a" size={22}/><div><strong style={{fontSize:13}}>Signed in as {session.user.email}</strong><p className="muted small" style={{margin:"5px 0 0"}}>Database policies limit records to their owner. This does not replace device-level consent or a production pairing credential.</p></div></div><div style={{display:"flex",gap:10,marginTop:18,flexWrap:"wrap"}}><button className="button" onClick={()=>refresh()}><Activity size={14} style={{display:"inline",marginRight:5}}/>Refresh data</button><button className="button" onClick={signOut}>Sign out</button></div></section>
      <footer className="muted small" id="settings" style={{marginTop:24}}>Spyteligent starter · Authorized devices only · <Clock3 size={12} style={{display:"inline",margin:"0 4px"}}/> data is shown as reported by the companion app.</footer>
    </main>
    <nav className="mobile-nav"><a className="active" href="#"><LayoutDashboard size={18}/>Overview</a><a href="#devices"><Smartphone size={18}/>Devices</a><a href="#location"><MapPin size={18}/>Location</a><a href="#media"><Camera size={18}/>Media</a><a href="#settings"><Settings size={18}/>Settings</a></nav>
    {showAdd && <div role="dialog" aria-modal="true" style={{position:"fixed",inset:0,background:"#020817c9",zIndex:30,display:"grid",placeItems:"center",padding:16}}><form className="card" style={{width:"min(100%,430px)"}} onSubmit={addDevice}><div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><h2 style={{marginTop:0}}>Add device record</h2><button type="button" className="button" onClick={()=>setShowAdd(false)} aria-label="Close"><X size={15}/></button></div><p className="muted small">This creates an owner-scoped record. It does not install an app or connect to the device.</p><label className="small">Device name</label><input value={newName} onChange={e=>setNewName(e.target.value)} required placeholder="e.g. My Android phone" style={{display:"block",width:"100%",padding:12,margin:"8px 0 14px",borderRadius:9,background:"#071225",border:"1px solid #29405f",color:"white"}}/><label className="small">Platform</label><select value={newPlatform} onChange={e=>setNewPlatform(e.target.value)} style={{display:"block",width:"100%",padding:12,margin:"8px 0 16px",borderRadius:9,background:"#071225",border:"1px solid #29405f",color:"white"}}><option value="android">Android</option><option value="ios">iPhone / iOS</option></select><button className="button primary" style={{width:"100%"}}>Create record</button></form></div>}
  </div>;
}

function Stat({icon,label,value,sub}:{icon:React.ReactNode;label:string;value:string;sub:string}) { return <div className="card"><div className="stat-top"><span>{label}</span><span className="stat-icon">{icon}</span></div><div className="stat-value">{value}</div><div className="stat-sub">{sub}</div></div>; }
function Feature({icon,title,status}:{icon:React.ReactNode;title:string;status:string}) { return <div className="feature"><span className="feature-icon">{icon}</span><div><strong style={{display:"block",marginBottom:4}}>{title}</strong><span className="muted" style={{fontSize:10}}>{status}</span></div></div>; }
