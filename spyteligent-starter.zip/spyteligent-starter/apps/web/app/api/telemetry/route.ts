import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

type Payload = {
  device_id?: string;
  battery_percent?: number | null;
  storage_total_bytes?: number | null;
  storage_free_bytes?: number | null;
};

export async function POST(request: NextRequest) {
  const authorization = request.headers.get("authorization") ?? "";
  const token = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
  if (!token) return NextResponse.json({ error: "Missing bearer token" }, { status: 401 });

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return NextResponse.json({ error: "Supabase is not configured" }, { status: 500 });

  const supabase = createClient(url, key, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false }
  });
  const { data: authData, error: authError } = await supabase.auth.getUser(token);
  if (authError || !authData.user) return NextResponse.json({ error: "Invalid session" }, { status: 401 });

  let body: Payload;
  try { body = await request.json() as Payload; }
  catch { return NextResponse.json({ error: "Invalid JSON" }, { status: 400 }); }

  if (!body.device_id || !/^[0-9a-f-]{36}$/i.test(body.device_id)) {
    return NextResponse.json({ error: "device_id must be a UUID" }, { status: 400 });
  }
  if (body.battery_percent != null && (!Number.isInteger(body.battery_percent) || body.battery_percent < 0 || body.battery_percent > 100)) {
    return NextResponse.json({ error: "battery_percent must be an integer from 0 to 100" }, { status: 400 });
  }
  for (const value of [body.storage_total_bytes, body.storage_free_bytes]) {
    if (value != null && (!Number.isSafeInteger(value) || value < 0)) {
      return NextResponse.json({ error: "Storage values must be non-negative safe integers" }, { status: 400 });
    }
  }

  const { data: device, error: deviceError } = await supabase
    .from("devices").select("id, owner_id, is_revoked").eq("id", body.device_id).maybeSingle();

  if (deviceError || !device || device.owner_id !== authData.user.id || device.is_revoked) {
    return NextResponse.json({ error: "Device not found, not owned by this user, or revoked" }, { status: 403 });
  }

  const { error: insertError } = await supabase.from("device_telemetry").insert({
    device_id: body.device_id,
    owner_id: authData.user.id,
    battery_percent: body.battery_percent ?? null,
    storage_total_bytes: body.storage_total_bytes ?? null,
    storage_free_bytes: body.storage_free_bytes ?? null
  });
  if (insertError) return NextResponse.json({ error: "Could not save telemetry" }, { status: 400 });

  await supabase.from("devices").update({ last_seen_at: new Date().toISOString() }).eq("id", body.device_id);
  return NextResponse.json({ ok: true }, { status: 201 });
}
