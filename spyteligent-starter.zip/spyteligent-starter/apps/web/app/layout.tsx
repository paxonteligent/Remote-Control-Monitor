import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Spyteligent | Device Management",
  description: "Privacy-first dashboard for devices you own or are authorized to manage."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
