package com.spyteligent.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.location.Location
import android.location.LocationManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            showLocationOnce()
        } else {
            status.text = "Location permission not granted. Sharing remains off."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 50, 40, 40)
        }
        status = TextView(this).apply { textSize = 16f; text = "Spyteligent companion\nLocation sharing is off." }
        val reportButton = Button(this).apply {
            text = "Send battery and storage status"
            setOnClickListener { reportStatusLocally() }
        }
        val locationButton = Button(this).apply {
            text = "Enable location sharing (one reading)"
            setOnClickListener { requestLocation() }
        }
        val settingsButton = Button(this).apply {
            text = "App settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = android.net.Uri.parse("package:$packageName")
            }) }
        }
        root.addView(status)
        root.addView(reportButton)
        root.addView(locationButton)
        root.addView(settingsButton)
        setContentView(root)
    }

    private fun reportStatusLocally() {
        val batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager
        val battery = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        status.text = String.format(
            Locale.US,
            "Status ready (not uploaded yet)\nBattery: %s%%\nStorage free: %.2f GB / %.2f GB\nAndroid: %s",
            if (battery in 0..100) battery.toString() else "unavailable",
            free / 1_073_741_824.0,
            total / 1_073_741_824.0,
            Build.VERSION.RELEASE
        )
        // TODO: after secure pairing, POST these values to the authenticated device telemetry endpoint.
        // Never embed a service-role key or shared long-lived secret in this app.
    }

    private fun requestLocation() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) showLocationOnce()
        else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
    }

    @Suppress("MissingPermission")
    private fun showLocationOnce() {
        val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = manager.getProviders(true)
        val best: Location? = providers.mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }.maxByOrNull { it.time }
        status.text = if (best != null) {
            "Location permission granted for this one user-requested reading.\nLat: %.5f\nLon: %.5f\nAccuracy: %.0f m\nNo upload occurs in this starter.".format(
                best.latitude, best.longitude, best.accuracy
            )
        } else {
            "Permission granted, but no cached location is available. Try again outdoors with Location enabled."
        }
        // TODO: upload only after explicit pairing, consent, and a revocable device credential exist.
    }
}
