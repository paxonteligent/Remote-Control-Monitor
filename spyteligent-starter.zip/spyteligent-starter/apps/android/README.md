# Android companion starter

This is a source starter, not a fully generated Android Studio Gradle project. Create a new Kotlin Android app in Android Studio, then add the provided `app/src/main/` files. Use a current stable Android Gradle Plugin and target SDK.

The sample deliberately requires a user tap to report battery/storage and another tap to enable location sharing. It does not implement persistent background tracking or restricted SMS/call-log access.
