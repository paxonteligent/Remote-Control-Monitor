create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  device_name text not null,
  platform text not null check (platform in ('android', 'ios', 'web')),
  model text,
  os_version text,
  app_version text,
  last_seen_at timestamptz,
  is_revoked boolean not null default false,
  paired_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.device_permissions (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references public.devices(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  feature text not null check (feature in ('location','media','telemetry','screen_share','app_inventory','calls_messages')),
  granted boolean not null default false,
  disclosure_version text,
  granted_at timestamptz,
  revoked_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(device_id, feature)
);

create table if not exists public.device_telemetry (
  id bigint generated always as identity primary key,
  device_id uuid not null references public.devices(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  battery_percent smallint check (battery_percent between 0 and 100),
  storage_total_bytes bigint check (storage_total_bytes >= 0),
  storage_free_bytes bigint check (storage_free_bytes >= 0),
  reported_at timestamptz not null default now()
);

create index if not exists device_telemetry_device_reported_idx
  on public.device_telemetry(device_id, reported_at desc);

create table if not exists public.location_points (
  id bigint generated always as identity primary key,
  device_id uuid not null references public.devices(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  accuracy_m double precision check (accuracy_m >= 0),
  recorded_at timestamptz not null default now()
);

create index if not exists location_points_device_recorded_idx
  on public.location_points(device_id, recorded_at desc);

create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references public.devices(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null unique,
  media_type text not null check (media_type in ('image','video')),
  mime_type text,
  file_size_bytes bigint check (file_size_bytes >= 0),
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.device_events (
  id bigint generated always as identity primary key,
  device_id uuid references public.devices(id) on delete set null,
  owner_id uuid not null references auth.users(id) on delete cascade,
  event_type text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.screen_sessions (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references public.devices(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null check (status in ('requested','active','stopped','denied','expired')),
  started_at timestamptz,
  stopped_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.devices enable row level security;
alter table public.device_permissions enable row level security;
alter table public.device_telemetry enable row level security;
alter table public.location_points enable row level security;
alter table public.media_assets enable row level security;
alter table public.device_events enable row level security;
alter table public.screen_sessions enable row level security;

-- Profiles
create policy "profile owner can read" on public.profiles for select to authenticated
  using (id = auth.uid());
create policy "profile owner can insert" on public.profiles for insert to authenticated
  with check (id = auth.uid());
create policy "profile owner can update" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- Device ownership is always the signed-in user.
create policy "owners manage their devices" on public.devices for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "owners manage device permissions" on public.device_permissions for all to authenticated
  using (owner_id = auth.uid() and exists (
    select 1 from public.devices d where d.id = device_id and d.owner_id = auth.uid()
  ))
  with check (owner_id = auth.uid() and exists (
    select 1 from public.devices d where d.id = device_id and d.owner_id = auth.uid()
  ));

create policy "owners read telemetry" on public.device_telemetry for select to authenticated
  using (owner_id = auth.uid());
create policy "owners insert telemetry" on public.device_telemetry for insert to authenticated
  with check (owner_id = auth.uid() and exists (
    select 1 from public.devices d where d.id = device_id and d.owner_id = auth.uid() and not d.is_revoked
  ));

create policy "owners manage location" on public.location_points for all to authenticated
  using (owner_id = auth.uid()) with check (
    owner_id = auth.uid() and exists (
      select 1 from public.devices d where d.id = device_id and d.owner_id = auth.uid() and not d.is_revoked
    )
  );

create policy "owners manage media metadata" on public.media_assets for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "owners read events" on public.device_events for select to authenticated
  using (owner_id = auth.uid());
create policy "owners insert events" on public.device_events for insert to authenticated
  with check (owner_id = auth.uid());

create policy "owners manage screen sessions" on public.screen_sessions for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Private Storage bucket. Upload/download policy is constrained to paths that begin
-- with the authenticated user's UUID. For production, also verify device ownership
-- in a trusted upload endpoint and use signed URLs for reads.
insert into storage.buckets (id, name, public)
values ('device-media', 'device-media', false)
on conflict (id) do nothing;

create policy "user uploads to own media prefix" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'device-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "user reads own media prefix" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'device-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "user deletes own media prefix" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'device-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- Realtime is optional. Enable the relevant tables from the Supabase dashboard
-- only after verifying the policies and expected traffic.
